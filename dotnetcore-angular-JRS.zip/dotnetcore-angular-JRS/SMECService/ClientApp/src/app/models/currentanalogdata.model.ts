export interface CurrentAnalogData {
  value: number;
  statusCode: number;
  samples: number;
}

