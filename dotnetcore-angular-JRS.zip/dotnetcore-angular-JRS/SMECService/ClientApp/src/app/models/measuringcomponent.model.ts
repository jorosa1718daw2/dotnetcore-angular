export interface MeasuringComponent {
  name: string;
}
